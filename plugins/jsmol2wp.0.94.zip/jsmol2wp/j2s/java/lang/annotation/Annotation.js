Clazz.declareInterface(java.lang.annotation,"Annotation");
