Clazz.load(["java.lang.RuntimeException"],"java.lang.ArithmeticException",null,function(){
c$=Clazz.declareType(java.lang,"ArithmeticException",RuntimeException);
});
